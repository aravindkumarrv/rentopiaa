function displayText() {
    var input = document.getElementById("userText").value;
    document.getElementById("output").innerHTML = input;
}
